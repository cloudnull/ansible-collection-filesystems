# ZFS-Setup Role

See defaults for all documented options and configuration.
